# ProQuity — Capital Seeker app

Built from the Figma file "App Designs → Capital Seeker - V2", styled in the ProQuity brand (Imperial Bordeaux palette, Newsreader headings, Plus Jakarta Sans text). One codebase runs on iPhone, Android and the web.

## What's in the app

**Getting started**
Splash → Welcome → Role selection → intro slides → sign up with email (6-digit code) or LinkedIn → login for existing users.

**Onboarding questions** (every branch in Figma)
- Raise Capital: Growth, Acquisition Financing, Investment Fund, Real Estate
- Seek Liquidity: Business Exit, Secondary Liquidity, plus LP Fund Interest

Then: Complete Personal Info (email sign-ups only) → Complete Your Profile (company, raise size, stage, revenue, pitch deck upload or link, geography, readiness) → visibility preference → Proquity AI finds matches and asks for notifications → upgrade screen → Dashboard.

**Main app**
- Dashboard: alerts, daily matches, Proquity AI shortcuts, follow-ups, pitch call reminders, recent AI chats
- Capital Providers and Capital Advisors tabs with search and filters
- Investor profile with Prev/Next, Message and Book a Pitch Call
- Send Connection Request with "Write with AI" (4 tones), attachments and daily limits
- Messages: filters, select and move chats, custom tags, chat screen
- Proquity AI chat and chat history
- Pitch calls: book, scheduled, history
- Profile, profile under review, Settings (change email with code, visibility, notifications, delete account, log out), Manage Subscription
- Resources: sample decks, legal templates, 8 calculators, video library, articles, news
- Side menu, notifications, paywall and "subscribe to unlock" sheets

**Free vs Premium**
On the free plan, investor names are hidden, three filter groups are locked, most resources are locked, and you get 1 connection request a day. Premium unlocks everything and gives 5 requests a day.

## Where things live

| What | File |
|---|---|
| Brand colors (with their names) and text styles | `src/theme/tokens.ts` |
| All onboarding questions and answers | `src/data/questionnaire.ts` |
| Sample investors, messages, news, etc. | `src/data/sample.ts` |
| Prices | `src/data/plans.ts` |
| Calculators | `src/data/calculators.ts` |
| Everything the app saves, and every action | `src/store/app-store.ts` |
| AI writing (on-device stand-in) | `src/utils/ai.ts` |
| Screens (one file per screen) | `src/app/` |

Lines marked `BACKEND:` show exactly where a real server connects.

## Run it

```
npm install
npx expo start          # scan the QR code with Expo Go, or press w for web
```

Checks:

```
npm run typecheck       # code types
npx expo lint           # code style
npm test                # 61 unit tests
npx expo export --platform web && npx serve -s dist -l 8090
npm run e2e             # 65-step robot test of the whole journey
```

## Not built yet (needs a backend)
Real LinkedIn sign-in and email codes, a server database, real AI (Claude API), in-app purchases, push notifications, file storage for decks and logos, video playback, and the Capital Provider and Capital Advisor experiences.

## Deploy the web version on Vercel
`vercel.json` is already set up (build command, output folder, and page routing).
- **From GitHub:** push this folder to a GitHub repo → vercel.com → Add New → Project → import the repo → Deploy. No settings to change.
- **From your computer:** `npm install`, then `npx vercel` and follow the prompts; `npx vercel --prod` for the live address.
